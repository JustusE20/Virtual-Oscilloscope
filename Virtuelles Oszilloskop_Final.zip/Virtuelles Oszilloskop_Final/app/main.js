var sim;
var webworker;

var div = document.getElementById("oszi");
var backgroundCanvas = document.getElementById("background");
var graphsCanvas = document.getElementById("graphs");
var menuCanvas = document.getElementById("menu");
var backgroundCtx = backgroundCanvas.getContext("2d");
var graphsCtx = graphsCanvas.getContext("2d");
var menuCtx = menuCanvas.getContext("2d");

var bundledCycles = 250;//default number of data stamps when drawing without changing time resolution
var ringBufferSize = 2500; //max index number of ring buffer
var triggerArea = 252; //number of cycles that get checked for trigger, minimum is value of bundled Cycles, triggerAreas overlap, so that no pulse etc. stays undetected; should maybe be made relative to trigger mode e.g. Edge practically just needs bundledCycles+1
var screenData;
var triggerBuffer; //copies ringBuffer if signal is triggered
var ringBuffer;
var stepCounter = 0;
var drawTime = 0;

var oszi = {
    simVisible: false,
    elements: [],
    init: function() {
        // canvas Einstellungen
        div.style.height = 9/16 * div.offsetWidth + "px";// change scale depending on space needed for new elements/measurements of real oscilloscope
        backgroundCanvas.width = div.clientWidth;
        backgroundCanvas.height = div.clientHeight;

        // initialize oszi-elements
        osziScreen.setPos(0.02, 0.02, 0.6, 0.4571);
        this.button1 = new Button(0.05, 0.5, 0.03, 0.02, 1);
        this.button2 = new Button(0.15, 0.5, 0.03, 0.02, 2);
        this.button3 = new Button(0.25, 0.5, 0.03, 0.02, 3);
        this.button4 = new Button(0.35, 0.5, 0.03, 0.02, 4);
        this.button5 = new Button(0.45, 0.5, 0.03, 0.02, 5);
        this.button6 = new Button(0.55, 0.5, 0.03, 0.02, 6);
        this.triggerButton = new Button(0.65, 0.05, 0.08, 0.04, "Trigger");
        this.modeCouplingButton = new Button(0.65, 0.1, 0.08, 0.04, "Mode Coupling");
        this.measurementButton = new Button(0.65, 0.15, 0.08, 0.04, "Meas");

        // initialize menu
        osziSettings.setMenu();
    
        backgroundCanvas.addEventListener("mouseup", (event) => {
            for(element of this.elements) {
                if(element.isInside(event.pageX - 9, event.pageY - 9)) {
                    osziSettings.pressButton(element.name);
                    break;
                }
            }
        });
        backgroundCanvas.addEventListener("mousemove", (event) => {
            for(element of this.elements) {
                if(element.isInside(event.pageX - 9, event.pageY - 9)) {
                    element.highlight();
                    break;
                } else {
                    element.draw();
                }
            }
        });
        window.addEventListener("resize", (event) => {
            div.style.height = 9/16 * div.offsetWidth + "px";// change scale depending on space needed for new elements/measurements of real oscilloscope
            backgroundCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
            backgroundCanvas.width = div.clientWidth;
            backgroundCanvas.height = div.clientHeight;
            osziScreen.updatePos();
            for(element of this.elements) {
                element.updatePos();
            }
            osziSettings.updateMenu();
            osziScreen.draw(screenData);
        });
    },
    toggleIFrame: function() {
        if(this.simVisible) {
          document.getElementById("circuitFrame").style.display = "none";
        } else {
          document.getElementById("circuitFrame").style.display = "";
        }
        this.simVisible = !this.simVisible;
    }
}

//SETTINGS/MENU:
var osziSettings = {
    menu: null,
    menuOptions: null,
    menuSettings: [0, 0, 0, 0],//adapt to number of menu options/menu.length, saves only the index of the chosen setting in the submenu-array
    activeMenu: null,
    menuName: null,
    activeSubmenu: null,
    //menuParameters: null,
    triggerActivated: false,
    triggerThreshold: 5,
    triggerPos: 0.5,//position of trigger time on screen, value 0 (left) - 1 (right)
    activeChannels: [false, false, false, false],
    
    //Menu functions:
    setMenu: function() {
        /*0*/let triggerMode = ["Edge", "Edge then Edge", "Pulswidth", "Bytepattern", "Or", "Rise/Falltime", "N Edge Burst", "Low Pulse", "Setup and Hold", "Video", "USB"];
        /*1*/let triggerSource = ["1", "2", "3", "4", "Extern", "Net", "Waveform-Gen", "Wavefom-Gen MOD (FSK/FM)"];
        /*2*/let triggerFlag = ["Rising", "Falling", "Alternating", "Either"];
        /*3*/let modeCoupling = ["Normal", "Auto"];
        /* empty menus for later integration
        let cursor = [];
        let measurement = [];
        let analyse = [];
        let aquire = [];
        let display = [];
        let saveRecall = [];
        let horizontal = [];
        let navigate = [];
        let calculation = [];
        let refWaveForm = [];
        let channel1 = [];
        let channel2 = [];
        let channel3 = [];
        let channel4 = [];
        let help = [];
        */

        this.menu = [triggerMode, triggerSource, triggerFlag, modeCoupling];
    },
    pressButton: function(buttonName) {
        if(typeof buttonName === 'string') {
            if(this.activeMenu != buttonName) {
                this.closeMenu();
                this.closeSubmenu();
                this.activeMenu = buttonName;
                switch(buttonName) {
                    case "Trigger":
                        this.openMenu("Trigger Menu", [0, 1, 2]);
                        break;
                    case "Mode Coupling":
                        this.openMenu("Mode Coupling", [3]);
                        break;
                    case "Meas":
                        this.openMenu("Measurement", []);
                        break;
                    default:
                        console.log("Button " + buttonName + " not found!");
                }
            }
        } else {
            if(this.activeSubmenu == buttonName - 1) {// go to next option of submenu
                this.openSubmenu(true);
                
            } else {// open new submenu, close old one if necessary
                if(this.activeSubmenu != null) {
                    this.closeSubmenu();
                }
                this.activeSubmenu = buttonName - 1;
                this.openSubmenu(false);
            }
        }
    },
    openMenu: function(menuName, menuOptions) {
        this.menuName = menuName;
        this.menuOptions = menuOptions;
        menuCtx.fillStyle = "black";
        menuCtx.fillRect(0, 0.85 * osziScreen.height, osziScreen.width, 0.15 * osziScreen.height);
        menuCtx.strokeStyle = "white";
        menuCtx.lineWidth = 1;
        menuCtx.strokeRect(0, 0.85 * osziScreen.height, osziScreen.width, 0.15 * osziScreen.height);
        menuCtx.font = "15px Arial";
        menuCtx.fillStyle = "white";
        menuCtx.textAlign = "left";
        menuCtx.fillText(menuName, 0.02 * osziScreen.width, 0.9 * osziScreen.height);
        menuCtx.textAlign = "center";
        for(let i = 0; i < menuOptions.length; i++) {
            menuCtx.fillText(this.menu[menuOptions[i]][this.menuSettings[menuOptions[i]]], (i/6 + 0.074) * osziScreen.width, 0.97 * osziScreen.height, 1/6 * osziScreen.width);//possible max width 
        }
    },
    updateMenu: function() {
        if(this.activeMenu != null) {
            this.openMenu(this.menuName, this.menuOptions);
            if(this.activeSubmenu != null) {
                this.openSubmenu(false);
            }
        }
    },
    closeMenu: function() {
        this.menuName = null;
        this.activeMenu = null;
        this.activeSubmenu = null;
        this.menuOptions = null;
        menuCtx.clearRect(0, 0.85 * osziScreen.height, osziScreen.width, 0.15 * osziScreen.height);
    },
    openSubmenu: function(stepMode) {
        if(this.menuOptions != null) {
            if(this.menu[this.menuOptions[this.activeSubmenu]] != null) {
                if(stepMode) {
                    menuCtx.clearRect(0, 0, osziScreen.width, osziScreen.height);
                    if(this.menuSettings[this.menuOptions[this.activeSubmenu]] < this.menu[this.menuOptions[this.activeSubmenu]].length - 1) {
                        this.menuSettings[this.menuOptions[this.activeSubmenu]]++;
                    } else {
                        this.menuSettings[this.menuOptions[this.activeSubmenu]] = 0;
                    }
                    this.openMenu(this.menuName, this.menuOptions);
                }
                //draw submenu background
                menuCtx.strokeStyle = "white";
                menuCtx.lineWidth = 2;
                menuCtx.fillStyle = "black";
                menuCtx.beginPath();
                menuCtx.roundRect(this.activeSubmenu/6 * osziScreen.width, (0.888 - 0.05 * (this.menu[this.menuOptions[this.activeSubmenu]].length+1)) * osziScreen.height, 1/6*osziScreen.width, (0.01 + 0.05 * (this.menu[this.menuOptions[this.activeSubmenu]].length))*osziScreen.height, 0.01*osziScreen.width);
                menuCtx.stroke();
                menuCtx.fill();

                //draw menu options
                for(let i = 0; i < this.menu[this.menuOptions[this.activeSubmenu]].length; i++) {
                    if(i == this.menuSettings[this.menuOptions[this.activeSubmenu]]) {
                        menuCtx.fillStyle = "green";
                    } else {
                        menuCtx.fillStyle = "white";
                    }
                    menuCtx.textAlign = "left";
                    menuCtx.fillText(this.menu[this.menuOptions[this.activeSubmenu]][i], (this.activeSubmenu/6 + 1/30) * osziScreen.width, (0.88 + 0.05 * (i - this.menu[this.menuOptions[this.activeSubmenu]].length)) * osziScreen.height, 2/15*osziScreen.width);
                }
            }
        }
    },
    closeSubmenu: function() {
        this.activeSubmenu = null;
        menuCtx.clearRect(0, 0, osziScreen.width, 0.85 * osziScreen.height);
    },
    getSetting: function(settingNumber) {
        return this.menu[settingNumber][this.menuSettings[settingNumber]];
    },

    //Trigger functions
    updateTrigger: function() {
        this.triggerThreshold = parseFloat(document.getElementById("tThreshold").value);
        this.triggerPos = parseFloat(document.getElementById("triggerPos").value);
    },
    toggleTrigger: function() {
        this.triggerActivated = !this.triggerActivated;
        if(this.triggerActivated) {
            document.getElementById("Trigger").textContent = "Trigger: ON";
            webworker = new Worker("worker.js");
            webworker.addEventListener("message", function(messageEvent) {
                triggerBuffer = Object.assign({}, ringBuffer);
                let leftBoundary = messageEvent.data - stepCounter + 0.5*(ringBufferSize-triggerArea) - osziSettings.triggerPos*bundledCycles;
                screenData.getData(leftBoundary, leftBoundary + triggerArea);
                osziScreen.draw(screenData);
            });
        } else {
            document.getElementById("Trigger").textContent = "Trigger: OFF";
            webworker.terminate();
            stepCounter = 0;
            drawTime = 0;
        }
    },
    toggleChannelActivation: function(channel, buttonName) {
        let status = this.activeChannels[channel];
        this.activeChannels[channel] = !status;
        if(status) {
          document.getElementById(buttonName).style.backgroundColor = "red";
        } else {
          document.getElementById(buttonName).style.backgroundColor = "green";
        }
    }
}

//VISUALISATION ELEMENTS:
var osziScreen = {
    x_rel: 0,
    y_rel: 0,
    width_rel: 0,
    height_rel: 0,
    xpoint: 0,
    ypoint: 0,
    width: 0,
    height: 0,
    posX: 0,
    posY: 0,
    innerWidth: 0,
    innerHeight: 0,
    xSquare: 0,
    ySquare: 0,
    setPos: function(x_rel, y_rel, width_rel, height_rel) {
        this.x_rel = x_rel;
        this.y_rel = y_rel;
        this.width_rel = width_rel;
        this.height_rel = height_rel;
        this.updatePos();
    },
    updatePos: function() {
        this.xpoint = Math.round(this.x_rel * backgroundCanvas.width);
        this.ypoint = Math.round(this.y_rel * backgroundCanvas.width);
        this.width = Math.round(this.width_rel * backgroundCanvas.width);
        this.height = Math.round(this.height_rel * backgroundCanvas.width);
        this.posX = this.xpoint + (this.width / 40);
        this.posY = this.ypoint + (this.height / 30);
        this.innerWidth = 5/7 * this.width;
        this.innerHeight = 3/4 * this.height;
        // adapt canvas graphs to new dimensions
        graphsCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        graphsCanvas.style.left = this.posX + "px";
        graphsCanvas.style.top = this.posY + "px";
        graphsCanvas.width = this.innerWidth;
        graphsCanvas.height = this.innerHeight;
        // adapt canvas menu to new dimensions
        menuCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        menuCanvas.style.left = this.xpoint + "px";
        menuCanvas.style.top = this.ypoint + "px";
        menuCanvas.width = this.width;
        menuCanvas.height = this.height;        
        this.drawIncrements();
    },
    drawIncrements: function() {// Zeichnen des Oszilloskop Bildschirm Hintergrund    
        backgroundCtx.fillStyle = "#888888";
        backgroundCtx.fillRect(this.xpoint, this.ypoint, this.width, this.height);

        backgroundCtx.beginPath();
        backgroundCtx.strokeStyle = "#f5f5f5";
        // draw Horizontal Lines
        for(let i = 0; i < 9; i++) {
            backgroundCtx.moveTo(this.posX, (this.posY + i * (this.innerHeight / 8)));
            backgroundCtx.lineTo((this.posX + this.innerWidth), (this.posY + i * (this.innerHeight / 8)));
        }
        // draw Vertical Lines
        for(let i = 0; i < 11; i++) {
            backgroundCtx.moveTo(this.posX + i * (this.innerWidth / 10), this.posY);
            backgroundCtx.lineTo((this.posX + i * (this.innerWidth / 10)), (this.posY + this.innerHeight));  
        }
        // draw Horizontal Increments
        for(let i = 0; i < 41; i++) {
            backgroundCtx.moveTo((this.posX + this.innerWidth * 0.49), (this.posY + i * (this.innerHeight / 40)));
            backgroundCtx.lineTo((this.posX + this.innerWidth * 0.51), (this.posY + i * (this.innerHeight / 40)));
        }
        // draw Vertical Increments
        for(let i = 0; i < 41; i++) {
            backgroundCtx.moveTo(this.posX + i * (this.innerWidth / 40), this.posY + this.innerHeight * 0.49);
            backgroundCtx.lineTo((this.posX + i * (this.innerWidth / 40)), (this.posY + this.innerHeight * 0.51));
        }
        backgroundCtx.stroke();       
        backgroundCtx.closePath();
    },
    draw: function(buffer) {
        screenData = buffer;
        graphsCtx.clearRect(0, 0, this.width, this.height);
        this.xSquare = parseFloat(document.getElementById("tps").value);
        this.ySquare = parseFloat(document.getElementById("vps").value);
        this.xScale = this.innerWidth / (10 * this.xSquare);
        this.yScale = this.innerHeight / (8 * this.ySquare);  
        let channelData = [buffer.CH1, buffer.CH2, buffer.CH3, buffer.CH4];
        let channelColor = ["#C82300", "#C88700", "#A5C800", "#00C88F"];
        for(var i = 0; i <= 3; i++) {
            if(osziSettings.activeChannels[i]) {
                graphsCtx.strokeStyle = channelColor[i];
                this.drawChart(channelData[i], buffer.timeSteps);
            }
        }
    },
    drawChart: function(channelData, timeSteps) {// Zeichnen der Messwerte
        graphsCtx.beginPath();
        graphsCtx.moveTo(0, this.innerHeight/2 - channelData[0]*this.yScale);
        let xCoord = 0;
        for(let i = 1; i < channelData.length; i++) {
            xCoord = xCoord + timeSteps[i];
            graphsCtx.lineTo(xCoord*this.xScale, this.innerHeight/2 - channelData[i]*this.yScale);
        }
        graphsCtx.stroke();
        graphsCtx.closePath();
    }
};

class Button {
    constructor(x_rel, y_rel, width_rel, height_rel, name) {
        this.x_rel = x_rel;
        this.y_rel = y_rel;
        this.width_rel = width_rel;
        this.height_rel = height_rel;
        this.name = name;//either number for unnamed buttons in the bottom or button tag
        this.xpoint = 0;
        this.ypoint = 0;
        this.width = 0;
        this.height = 0;
        oszi.elements.push(this);
        this.updatePos();
    }
    updatePos() {
        this.xpoint = Math.round(this.x_rel * backgroundCanvas.width);
        this.ypoint = Math.round(this.y_rel * backgroundCanvas.width);
        this.width = Math.round(this.width_rel * backgroundCanvas.width);
        this.height = Math.round(this.height_rel * backgroundCanvas.width);
        this.draw();
    }
    draw() {
        backgroundCtx.fillStyle = "grey";
        backgroundCtx.fillRect(this.xpoint, this.ypoint, this.width, this.height);
        backgroundCtx.strokeStyle = "black";
        backgroundCtx.lineWidth = 1;
        backgroundCtx.strokeRect(this.xpoint, this.ypoint, this.width, this.height);
        if(typeof this.name === 'string') {
            backgroundCtx.font = "15px Arial";
            backgroundCtx.fillStyle = "black";
            backgroundCtx.textAlign = "center";
            backgroundCtx.textBaseline = "middle";
            backgroundCtx.fillText(this.name, this.xpoint + this.width/2, this.ypoint + this.height/2, this.width);
        }
    }
    highlight() {
        backgroundCtx.strokeStyle = "black";
        backgroundCtx.lineWidth = 2;
        backgroundCtx.strokeRect(this.xpoint + 1, this.ypoint + 1, this.width - 2, this.height - 2);
    }
    isInside(xmouse, ymouse) {
        const distanceX = this.xpoint + this.width;
        const distanceY = this.ypoint + this.height;
        if(xmouse >= this.xpoint && xmouse <= distanceX && ymouse >= this.ypoint && ymouse <= distanceY) {
            return true;
        } else {
            return false;
        } 
    }
}

//DATA MANAGEMENT:
class Buffer {
    constructor() {
        this.CH1 = [];
        this.CH2 = [];
        this.CH3 = [];
        this.CH4 = [];
        this.timeSteps = [];
    }
    pushData() {//only used by ringBuffer
        this.CH1.shift();
        this.CH2.shift();
        this.CH3.shift();
        this.CH4.shift();
        this.timeSteps.shift();
        this.CH1[ringBufferSize] = sim.getNodeVoltage("CH1");
        this.CH2[ringBufferSize] = sim.getNodeVoltage("CH2");
        this.CH3[ringBufferSize] = sim.getNodeVoltage("CH3");
        this.CH4[ringBufferSize] = sim.getNodeVoltage("CH4");
        this.timeSteps[ringBufferSize] = sim.getTimeStep();
    }
    getData(startIndex, endIndex) {//getting data from ringBuffer
        this.CH1 = ringBuffer.CH1.slice(startIndex, endIndex);
        this.CH2 = ringBuffer.CH2.slice(startIndex, endIndex);
        this.CH3 = ringBuffer.CH3.slice(startIndex, endIndex);
        this.CH4 = ringBuffer.CH4.slice(startIndex, endIndex);
        this.timeSteps = ringBuffer.timeSteps.slice(startIndex, endIndex);
    }
    checkTrigger() {
        let triggerValues = eval("this.CH" + osziSettings.getSetting(1) + ".slice(0.5*(ringBufferSize-triggerArea), 0.5*(ringBufferSize+triggerArea))");//change, when other trigger sources than input channels 1-4 are implemented
        let triggerMode = osziSettings.getSetting(0);
        osziSettings.updateTrigger();
        webworker.postMessage([triggerValues, triggerMode, osziSettings.getSetting(2), osziSettings.triggerThreshold, stepCounter]);//send timeSteps for more complex trigger modi
    }
}

/*Code to measure processing speed of programm segment
var t0 = performance.now();
var t1 = performance.now();
console.log(`Durchlauf dauerte ${t1 - t0} Millisekunden.`);
*/

function didStep() {
    ringBuffer.pushData();
    stepCounter++;
    if(osziSettings.triggerActivated) {
        if(stepCounter%bundledCycles == 0) {
            ringBuffer.checkTrigger();
        }
    } else {
        drawTime = drawTime + sim.getTimeStep();
        if(drawTime >= 10*osziScreen.xSquare) {
            screenData.getData(ringBufferSize - stepCounter, ringBufferSize);
            osziScreen.draw(screenData);
            stepCounter = 0;
            drawTime = 0;
        }
    }
    if(osziScreen.xSquare != 0) {
        sim.setTimeStep(10*osziScreen.xSquare / bundledCycles);
    }
}

function round(x) {
    return Math.round(x*1000)/1000;
}
  
// called when simulator updates its display
function didUpdate() {
    var info = document.getElementById("info");
    info.innerHTML = "time = " + round(sim.getTime()) + "<br>running = " + sim.isRunning();
    var bstr = "";
    var bval = 0;
    var i;
    for (i = 7; i >= 0; i--) {
        var v = sim.getNodeVoltage("D" + i);
        if (v > 2.5) {
            bstr += "1";
            bval = 2*bval+1;
        } else {
            bstr += "0";
            bval = 2*bval;
        }
    }
    info.innerHTML += "<br>counter value = <tt>" + bstr + "</tt> = " + bval;
  
    // go through list of elements
    var elmList = sim.getElements();
    var rcount = 0;
    for (const elm of elmList) {
        if (elm.getType() == "ResistorElm") {
            // show info about each resistor
            rcount++;
            info.innerHTML += "<br>resistor " + rcount + " voltage diff = " + round(elm.getVoltageDiff());
            info.innerHTML += "<br>resistor " + rcount + " current = " + round(elm.getCurrent() * 1000) + " mA";
        } else if (elm.getType() == "LabeledNodeElm") {
            // show voltage of each labeled node
            info.innerHTML += "<br>V(" + elm.getLabelName() + ") = " + round(elm.getVoltage(0));
        }
    }
}

//INITIATION:
function simLoaded() {
    // set up callbacks on timestep and update
    sim = document.getElementById("circuitFrame").contentWindow.CircuitJS1;
    sim.ontimestep = didStep;
    sim.onupdate = didUpdate;

    screenData = new Buffer();
    ringBuffer = new Buffer();
}

oszi.init();
// set up callback
document.getElementById("circuitFrame").contentWindow.oncircuitjsloaded = simLoaded;